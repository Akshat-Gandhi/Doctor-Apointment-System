# django-doctor-appointment

Doctor appointment application using django

### Live : [Demo](https://docmed-11.herokuapp.com/)

### DATABASE
#### Local : Sqlite
#### Live : postgresql
[![HitCount](http://hits.dwyl.com/{nazmul199512}/{django-doctor-appointment}.svg)](http://hits.dwyl.com/{nazmul199512}/{django-doctor-appointment})
## Screen Shots

### Search Doctor

![](12.PNG)
![](13.PNG)

### Doctor Registration

![](Capture1.PNG)

### Patient Registration

![](Capture2.PNG)
